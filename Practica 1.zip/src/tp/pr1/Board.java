package tp.pr1;
import tp.pr1.util.*;

public class Board {


	private Cell[][] board;

	private int boardSize;

	private ArrayAsList listaVacia;

	public Board(int boardSize) {
		this.boardSize = boardSize;
		this.board = new Cell [boardSize][boardSize];

		for (int i = 0; i < boardSize; i++) {
			for (int j = 0; j < boardSize; j++) {
				this.board[i][j] = new Cell(0) ;
			}
		}
		CrearArray();
	}

	public void CrearArray() {//Creamos el array de posiciones vacias		
		this.listaVacia= new ArrayAsList(boardSize);
		for(int i=0; i< boardSize; i++) {
			for (int j = 0; j < boardSize; j++) {
				Position pos= new Position(0,0);
				pos.setX(i);
				pos.setY(j);
				if(Vacia(i,j))
					listaVacia.insertar(pos);
			}
		}
	}

	public ArrayAsList devolverLista() {
		return listaVacia;
	}

	public void setCell(Position pos, int value) {
		int x;
		int y;

		x = pos.getX();
		y = pos.getY();
		board[x][y].setValor(value);
		CrearArray();

	}

	public boolean Vacia(int i, int j) {
		if(board[i][j].isEmpty())
			return false;
		else return true;
	}

	public int maxValor() {
		int max = 0;
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board.length; j++) {
				if(this.board[i][j].getValor() > max) {
					max = this.board[i][j].getValor();
				}
			}
		}
		return max;	
	}

	public MoveResults executeMove(Direction dir) {
		MoveResults movimiento = new MoveResults();
		int fila;
		int columna;

		if(dir == Direction.UP) {
			fila=-1;
			columna=0;
			if(desplazarUP(fila, columna))
				movimiento.setMoved(true);
			movimiento.setPoints(FusionarLEFTYUP(columna,fila));
			desplazarUP(fila, columna);//Deplazamos para que se nos junten los numeros depues de fusionar

		}
		else if(dir==Direction.DOWN) {
			fila = 1;
			columna=0;
			if(desplazarDOWN(fila, columna))
				movimiento.setMoved(true);
			movimiento.setPoints(FusionarDOWNYRIGHT(columna, fila));
			desplazarDOWN(fila, columna);

		}
		else if(dir == Direction.LEFT) {
			columna =-1;
			fila = 0;
			if(desplazarLEFT(fila, columna))
				movimiento.setMoved(true);
			movimiento.setPoints(FusionarLEFTYUP(columna,fila));
			desplazarLEFT(fila, columna);

		}else if(dir == Direction.RIGHT){ 
			columna = 1;
			fila=0;
			if(desplazarRIGHT(fila, columna))
				movimiento.setMoved(true);
			movimiento.setPoints(FusionarDOWNYRIGHT(columna, fila));
			desplazarRIGHT(fila, columna);

		}

		if(movimiento.getPoints()!=0)
			movimiento.setMoved(true);// Por si no ha desplazado pero si fusionado

		movimiento.setMaxToken(maxValor());
		return movimiento;//Devuelve un movimiento
	}

	public boolean  desplazarUP(int valorFila, int valorColumna) {
		boolean posible = false;
		int numHuecos;

		for(int columna=0; columna < boardSize; columna++){
			numHuecos=0;
			for(int fila=0; fila<boardSize;fila++){
				if(!board[fila][columna].isEmpty()){
					numHuecos++;
				}else if(numHuecos>0){
					Position pos = new Position(0,0);
					pos.setX(fila+valorFila*numHuecos);
					pos.setY(columna);
					setCell(pos,board[fila][columna].getValor());
					Position posNeig= new Position(0,0);
					posNeig.setX(fila);
					posNeig.setY(columna);
					setCell(posNeig, 0);
					posible=true;
				}
			}
		}
		return posible;
	}

	public boolean desplazarDOWN(int valorFila, int valorColumna) {
		boolean posible = false;
		int numHuecos;
		for(int columna=0; columna < boardSize; columna++){
			numHuecos=0;
			for(int fila=boardSize-1; fila>=0;fila--){
				if(!board[fila][columna].isEmpty()){
					numHuecos++;
				}else if(numHuecos>0){
					Position pos = new Position(0,0);
					pos.setX(fila+valorFila*numHuecos);
					pos.setY(columna);
					setCell(pos,board[fila][columna].getValor());
					Position posNeig= new Position(0,0);
					posNeig.setX(fila);
					posNeig.setY(columna);
					setCell(posNeig, 0);
					posible=true;
				}
			}
		}
		return posible;
	}

	public boolean desplazarLEFT(int valorFila, int valorColumna) {
		boolean posible = false;
		int numHuecos;

		for(int fila=0; fila < boardSize; fila++){
			numHuecos=0;
			for(int columna=0; columna<boardSize;columna++){
				if(!board[fila][columna].isEmpty()){
					numHuecos++;
				}else if(numHuecos>0){
					Position pos=new Position(0,0);
					pos.setX(fila);
					pos.setY(columna+valorColumna*numHuecos);
					setCell(pos,board[fila][columna].getValor());
					Position posNeig= new Position(0,0);
					posNeig.setX(fila);
					posNeig.setY(columna);
					setCell(posNeig, 0);
					posible = true;
				}
			}
		}
		return posible;
	}

	public boolean desplazarRIGHT(int valorFila, int valorColumna) {
		boolean posible = false;
		int numHuecos;

		for(int fila=0; fila < boardSize; fila++){
			numHuecos=0;
			for(int columna=boardSize-1; columna>=0;columna--){
				if(!board[fila][columna].isEmpty()){
					numHuecos++;
				}else if(numHuecos>0){
					Position pos=new Position(0,0);
					pos.setX(fila);
					pos.setY(columna+valorColumna*numHuecos);
					setCell(pos,board[fila][columna].getValor());
					Position posNeig= new Position(0,0);
					posNeig.setX(fila);
					posNeig.setY(columna);
					setCell(posNeig, 0);
					posible = true;
				}
			}
		}
		return posible;
	}

	public int FusionarDOWNYRIGHT(int columna, int fila) {
		Cell neighbour;
		Cell celda;
		int score=0;
		for(int i=boardSize-1; i >= 0; i--) {
			for(int j=boardSize-1; j >=  0; j--){
				celda=board[i][j];
				if(celda.isEmpty()) {
					if((i-fila >= 0) && (j-columna >=0)) {
						neighbour=board[i-fila][j-columna];
						score+=Fusionar(celda,neighbour, i-fila, j-columna);
					}
				}
			}
		}
		return score;
	}

	public int FusionarLEFTYUP(int columna, int fila) {
		Cell neighbour;
		Cell celda;
		int score=0;

		for(int i=0; i < boardSize; i++) {
			for(int j=0; j <  boardSize; j++){
				celda=board[i][j];
				if(celda.isEmpty()) {
					if((i - fila <boardSize)&&(j-columna<boardSize)){
						neighbour=board[i-fila][j-columna];
						score+=Fusionar(celda,neighbour, i-fila, j-columna);
					}
				}
			}
		}
		return score;
	}

	public int Fusionar(Cell celda, Cell neighbour, int i, int j) {

		int puntos=0;
		if(celda.doMerge(neighbour)) {
			celda.setValor(neighbour.getValor()+celda.getValor());
			puntos= celda.getValor();
			Position pos = new Position(0,0);
			pos.setX(i);
			pos.setY(j);
			setCell(pos, 0);
		}
		return puntos;
	}
	
	public boolean TableroLleno() {
		boolean lleno=true;
		int i=0;
		int j=0;

		while(i<boardSize && lleno) {
			while(j<boardSize && lleno) {
				if(Vacia(i,j))
					lleno=false;
				j++;	
			}
			j=0;
			i++;
		}
		return lleno;
	}

	public boolean JuegoFinalizado() {
		boolean fin=true;
		int i=0;
		int j=0;

		while(i<boardSize && fin) {
			while(j<boardSize && fin) {

				if(i>0 &&board[i][j].getValor()==board[i-1][j].getValor())
					fin=false;
				if(i< boardSize -1 && board[i][j].getValor()==board[i+1][j].getValor())
					fin=false;
				if( j>0 && board[i][j].getValor()==board[i][j-1].getValor() )
					fin=false;
				if(j < boardSize -1  && board[i][j].getValor()==board[i][j+1].getValor())
					fin=false;
				j++;	
			}
			j=0;
			i++;
		}
		
		return fin;
	}

	public String toString() {
		MyStringUtils dibujo = new MyStringUtils();
		String resultado = "";
		int cellSize=7;
		String space= " ";
		String vDelimiter= "|";
		String hDelimiter="-";
		int val;
		for (int h = 0; h <= board.length; h++) {
			resultado += "\n";
			for (int i = 0; i <board.length; i++) {
				resultado+= dibujo.centre(dibujo.repeat(hDelimiter, cellSize), cellSize);
			}
			resultado+="\n";
			if(h< board.length) {
				for (int j = 0; j <board.length; j++) {
					val=this.board[h][j].getValor();
					if(val!=0){
						resultado+=dibujo.centre(vDelimiter+ dibujo.centre(String.valueOf(val), cellSize),cellSize);
					}
					else
						resultado+=dibujo.centre(vDelimiter+ dibujo.repeat(space, cellSize),cellSize);

				}
				resultado+=vDelimiter;
			}

		}
		return resultado;
	}

}