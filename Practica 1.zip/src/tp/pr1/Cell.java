package tp.pr1;

public class Cell {
	private int valor;
	
	public Cell(int valor) {
		this.valor = valor;
	}

	public boolean isEmpty(){
		if(this.valor==0) return false;
		else return true;
	}

	public boolean doMerge(Cell neighbour) {
		if(valor==neighbour.valor) {
			return true;
		}
		else return false;
	}

	public int getValor() {
		return valor;
	}

	public void setValor(int valor) {
		this.valor = valor;
	}


}