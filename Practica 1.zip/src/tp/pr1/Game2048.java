package tp.pr1;

import java.util.Scanner;
import java.util.Random;

public class Game2048 {

	
	public static void main(String[] args) {
		long seed;
		if(args.length==3)//Si hay 3 argumentos
			seed=Long.parseLong(args[2]);
		else
			seed = new Random().nextInt(1000);//SI solo hay dos argumentos
		Random rand = new Random(seed);
		Game game = new Game(Integer.parseInt(args[0]),Integer.parseInt(args[1]), rand);
		Scanner sc= new Scanner(System.in);
		Controller controller = new Controller(game,sc);
		controller.run();
		
	}
}
