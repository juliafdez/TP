package tp.pr1;

public enum Direction {
	UP, DOWN, RIGHT, LEFT;
}
