package tp.pr1;

import java.util.Scanner;

public class Controller {
	private Game game;
	private Scanner in;
	private boolean fin;
	
	public Controller(Game game, Scanner in) {
		super();
		this.game = game;
		this.in = in;
		this.fin=false;
	}

	public void run() {
		System.out.println(this.game.toString());
		while(!fin) {
			System.out.print("Command > ");
			String ask=in.next();
			if(ask.equalsIgnoreCase("move")) {
				String dir = in.next();
				if(dir.equalsIgnoreCase("right")) {
					this.game.move(Direction.RIGHT);
				}else if(dir.equalsIgnoreCase("left")) {
					this.game.move(Direction.LEFT);
				}else if(dir.equalsIgnoreCase("up")) {
					this.game.move(Direction.UP);
				}else if(dir.equalsIgnoreCase("down")) {
					this.game.move(Direction.DOWN);
				}else{
					System.out.println("Movimiento introducido no valido\n");
				}
				System.out.println(this.game.toString());
			}else if(ask.equalsIgnoreCase("help")) {
				System.out.println("Move <direction>: execute a move in one of the four directions, up, down, left, right\r\n" + 
						"Reset: start a new game\r\n" + 
						"Help: print this help message\r\n" + 
						"Exit: terminate the program");

			}else if(ask.equalsIgnoreCase("reset")) {
				this.game.reset();
				System.out.println(this.game);
			}else if(ask.equalsIgnoreCase("exit")) {
				this.fin=true;
			}else {
				System.out.println("Comando introducido no valido\n");
			}
			
			
			if(game.win()) {
				System.out.println("Has ganado!");
				fin=true;
			}
			else if(game.lost()) {
				System.out.println("Has perdido");
				fin=true;
			}
		}
	}
	
	
	
}
