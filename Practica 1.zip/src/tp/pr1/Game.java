package tp.pr1;
import java.util.Random;

import tp.pr1.util.ArrayAsList;

public class Game {

	private Board board;
	private int size; 
	private int initCells; 
	private Random myRandom;
	private int score;
	private int high;
	private boolean lost;

	public Game(int size, int initCells, Random myRandom) {

		this.size = size;
		this.initCells = initCells;
		this.myRandom = myRandom;
		reset();

	}

	private Position Libre() {
		return (Position) ArrayAsList.choice(board.devolverLista(), myRandom);
	}

	public void aleatPos() {		
		board.setCell(Libre(), aleatValue());
		high=board.maxValor();
	}

	public int aleatValue() {
		int al=this.myRandom.nextInt(100);
		if(al <= 90) {
			return 2;
		}else return 4;
	}


	public void move(Direction dir) {
		MoveResults mov= new MoveResults();
		mov=this.board.executeMove(dir);
		if(mov.isMoved()) {
			score+=mov.getPoints();
			high=mov.getMaxToken();
			aleatPos();
		}
		if(board.JuegoFinalizado() && board.TableroLleno()) {
			lost=true;
		}
		
	}

	public void reset() {
		this.board=new Board(this.size);
		score=0;
		high =0;
		for(int i=0; i < initCells; i++){
			aleatPos();
		}
	}

	public boolean win() {
		return high==2048;
	}
	
	public boolean lost() {
		return lost;
	}
	
	public String toString() {
		return this.board + "Highest: " + high + " Score: " + score;
	}

}