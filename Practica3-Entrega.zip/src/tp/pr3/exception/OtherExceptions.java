package tp.pr3.exception;

import java.util.Scanner;

public class OtherExceptions extends Exception {
	
		public OtherExceptions(String mensaje) {
			System.out.println(mensaje);
		}
		
}
